<?php
include "dbconn.php";

$method = strtolower($_SERVER["REQUEST_METHOD"]);
switch($method) {
	case 'get':				// select	
		$data = $_GET;
		break;
	case 'post':			// insert
		$data = $_POST;
		break;
	case 'put':				// update
		parse_str(file_get_contents("php://input"),$put_vars);
		$data = $put_vars;
		break;
	case 'delete':			// delete
		parse_str(file_get_contents("php://input"),$put_vars);
		$data = $put_vars;
		break;
}

$userName = $data["uname"];
$passPwd = $data["pword"];
//echo "username:$userName  pass:$passPwd";
$query = "SELECT Login FROM memberlist WHERE Login='$userName' and Password='$passPwd'";

$dataArray = array();
try {
	$result = mysqli_query($conn, $query);
	if ($method == "get") {
		while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			array_push($dataArray, $row);
		}
		echo json_encode($dataArray);
	} else {
		echo json_encode($result);
	}
} catch(MySQLException $e) {
	echo json_encode($e->getMessage());
}

//echo $data;
?>