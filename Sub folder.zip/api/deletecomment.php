<?php
include "dbconn.php";

parse_str(file_get_contents("php://input"),$data);
//parse_str(file_get_contents("php://input"),$data);
$msg_id = $data["review_id"];
$sql = "DELETE FROM message WHERE msgid=$msg_id";
//echo $sql;
$result = mysqli_query($conn,$sql);//or die("Could not issue delete query");
if ($result)
{
	echo json_encode("deleted");
}
else
{
	echo json_encode("error");
}

?>