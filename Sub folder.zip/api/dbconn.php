<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT");
$hostname = "fdb12.biz.ht";
$username = "2181330_305cde";
$password = "Ben00000000";
$dbname = "2181330_305cde";
$conn = null;
$conn = mysqli_connect($hostname, $username, $password, $dbname);
?>

