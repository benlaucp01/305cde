<?php
header('content-type: appliction/json;charset=utf-8');
$link = mysqli_connect("localhost","root","00000000");
mysqli_select_db("305cde");

$action = $_GET["action"];
if($action=="list"){
    $sql = "SELECT * FROM message order by msgid desc";
    $result = mysqli_query($sql);
    if (mysqli_errno() ==0){
        $json['message']="success";
        while ($data = mysqli_fetch_assoc($result)){
            $jason['message'][]=$data;
        }
    }else{
        $json['message']="fail";
    }
}else if($action=="detail"){
    $id=$_GET["id"];
    $sql = "SELECT * FROM message WHERE msgid=$id";
     $result = mysqli_query($sql);
    if(mysqli_errno()==0){
        $json['message']="success";
        while($data = mysqli_fetch_assoc($result)){
            $json['message'][]=$data;
    }}else{$json['message']="fail";
          }
}else if($action=="add"){ 
    $name = $_GET["name"];
    $title = $_GET["title"];
    $content = $_GET["content"];
    $time = $_GET["time"];
    $sql = "INSERT INTO message (user,title,content)VALUES('$user','$title','$content')";
    mysqli_query($sql);
    if(mysqli_errno()==0){
        $json['message']="success";
    }else {
        $json['message']="fail";
    }
}else if($action=="edit"){
     $name = $_GET["name"];
    $title = $_GET["title"];
    $content = $_GET["content"];
    $time = $_GET["time"];
    $sql = "UPDATE message SET user='$name',title='$title',content='$content',time='$time' WHERE msgid=$id";
    mysqli_query($sql);
    if(mysqli_errno()==0){
        $json['message']="success";
    }else {
        $json['message']="fail";
    }
}else if($action=="delete"){  
    $id = $_GET["id"];
    $sql = "DELETE FROM message WHERE msgid=$id";
    mysqli_query($sql);
     if(mysqli_errno()==0){
        $json['message']="success";
    }else {
        $json['message']="fail";
    }
}
$json_code = json_encode($json);
if ($json_code=="null"){
    echo"{'message':'no service'}";
}else{
    echo urldecode($json_code);
}
?>  