<?php
include "dbconn.php";

$result = mysqli_query($conn,"select * from message order by msgid DESC") or die("Could not issue MySQL query");

$return_arr=array();
	while ($row=mysqli_fetch_array($result)) {
	array_push($return_arr,$row);
	}
echo json_encode($return_arr);

?>  