<?php
include('connectDBi.php');
$sqlget = "SELECT * FROM message ORDER BY msgid desc";
$sqldata = mysqli_query($conn,$sqlget) or die('error cant get from db');

$logname=$_POST['username'];
echo "User=".$logname;


echo"<table border=1>";
echo"<tr><th>ID</th><th>username</th><th>title</th><th>content</th><th></th></tr>";

while($row=mysqli_fetch_array($sqldata,MYSQLI_ASSOC)){
		echo"<tr><td>";
		echo $row['msgid'];
		echo"</td><td>";
		echo $row['user'];
		echo"</td><td>";
		echo $row['title'];
		echo"</td><td>";
		echo $row['content'];
		if($row['user']==$logname){
		echo "</td><td><a href='editpage.php?".$row['msgid']."'>Edit</a></td></tr>";
}else{
	echo"</td></tr>";
}
		}
		echo"</table>";
		

?>		