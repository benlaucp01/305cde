<?php
include "dbconn.php";

parse_str(file_get_contents("php://input"),$data);
		$msg_id = $data["msg_id"];
		$title= $data["newtitle"];
		$comment = $data["newcontent"];
		$sql = "UPDATE message SET content='$comment',title='$title' WHERE msgid=$msg_id";
try{
		$result = mysqli_query($conn,$sql);//or die("Could not issue update query");
		if ($result)
		{
			echo json_encode("updated");	
		}
		else
		{
			echo json_encode("failed");
		}
} catch(Exception $e) {
	echo json_encode($e->getMessage());
}
?>