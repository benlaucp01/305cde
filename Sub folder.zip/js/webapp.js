// JavaScript Document
window.addEventListener("load",function() {
    setTimeout(function(){
        window.scrollTo(0, 1);
    }, 0);
});

$(document).on('pageinit', function(e, data){  
    var pathname = window.location.pathname.toLowerCase();
	if(pathname.indexOf("home.html") == -1 && pathname.indexOf("register.html") == -1 && pathname.indexOf("regpage.html") == -1)
		checkMember();
	
});

var host = 'http://benlau.me.ht/'

function logout() {
	localStorage.clear();
	window.location.href="index.html";
};

function showHomeHeader() {
		$('#logstatus').html("Home");
}

function showLoginUser() {
	var Newloginusername=localStorage.getItem("logname"); 
	$('#logstatus').html("Wellcome " + Newloginusername);
	$('#logout').show();
	//alert ("Wellcome " + Newloginusername);
}

function isMember() {
	var loginName = localStorage.getItem("logname");
	console.log("current login:"+loginName);
	return (loginName!=null && loginName != "");
}

function checkMember(){
    if (localStorage.logname != undefined) { 
        }
        else{
            //window.location.href="home.html";
        }
}

